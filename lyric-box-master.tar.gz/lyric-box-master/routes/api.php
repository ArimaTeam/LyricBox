<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

# category
Route::group(['prefix' => '/categories'], function(){
    Route::get('/', 'Api\CategoryController@list');
    Route::get('/{id}', 'Api\CategoryController@details');
});

# singer
Route::group(['prefix' => '/singers'], function(){
    Route::get('/', 'Api\SingerController@list');
    Route::get('/{id}', 'Api\SingerController@details');
});

# music
Route::group(['prefix' => '/musics'], function(){
    Route::get('/', 'Api\MusicController@list');
    Route::get('/{id}', 'Api\MusicController@details');
});
