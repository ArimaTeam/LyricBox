<?php

namespace Tests\Unit;

use Tests\TestCase;

class CategoryTest extends TestCase
{
    public function testList()
    {
        $response = $this->get('/api/categories');

        $response->assertSuccessful();
        $response->assertJson(['code' => 200]);
    }

    public function testListWithParameters()
    {
        $query = http_build_query(['limit' => 5, 'offset' => 0, 'order_by' => 'id', 'ascending' => true]);
        $response = $this->get("/api/categories?{$query}");

        $response->assertSuccessful();
        $response->assertJson(['code' => 200]);
    }
}
