<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lyric extends Model
{
    protected $fillable = [
        'music_id', 'text', 'language'
    ];

    public function music()
    {
        return $this->belongsTo(Music::class);
    }
}
