<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MusicScore extends Model
{
    protected $fillable = [
        'music_id',
    ];

    public function music()
    {
        return $this->belongsTo(Music::class);
    }
}
