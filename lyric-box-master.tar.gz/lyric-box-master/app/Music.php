<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Music extends Model
{
    protected $fillable = [
        'category_id', 'singer_id', 'title', 'poster'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function singer()
    {
        return $this->belongsTo(Singer::class);
    }

    public function lyrics()
    {
        return $this->hasMany(Lyric::class);
    }

    public function scores()
    {
        return $this->hasMany(MusicScore::class);
    }
}
