<?php

namespace App\Http\Middleware;

use Closure;

class Localization
{
    public function handle($request, Closure $next)
    {
        $locale = $request->hasHeader('X-localization') ? $request->header('X-localization') : 'en';

        app()->setLocale($locale);

        return $next($request);
    }
}
