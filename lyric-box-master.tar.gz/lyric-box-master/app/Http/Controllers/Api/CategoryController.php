<?php

namespace App\Http\Controllers\Api;

use App\Category;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Config;
use Schema;

class CategoryController extends AbstractController
{
    public function list(Request $request)
    {
        $offset = $request->query->getInt('offset', 0);
        $limit = $request->query->getInt('limit', Config::get('api.limit'));
        $orderBy = $request->query->get('order_by', 'id');
        $direction = $request->query->getBoolean('ascending', true) ? 'ASC' : 'DESC';

        if(!Schema::hasColumn('categories', $orderBy)) {
            abort(JsonResponse::HTTP_BAD_REQUEST, __('messages.request.order_by.invalid_filed'));
        }

        $categories = Category::query()->orderBy($orderBy, $direction)->offset($offset)->limit($limit);
        $data = [];

        $pagination = [];
        $pagination['count'] = $categories->count();
        $pagination['has_more'] = $pagination['count'] > $offset + $limit;

        foreach ($categories->get() as $key => $category) {
            $data[$key]['id'] = $category->id;
            $data[$key]['name'] = $category->name;
            $data[$key]['icon'] = $category->icon;
        }

        return $this->result($data, $pagination);
    }

    public function details($id)
    {
        $category = Category::query()->findOrFail($id);
        $data = [];

        $data['id'] = $category->id;
        $data['name'] = $category->name;
        $data['icon'] = $category->icon;

        return $this->result($data);
    }
}
