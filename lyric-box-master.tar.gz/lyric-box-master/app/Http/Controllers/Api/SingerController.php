<?php

namespace App\Http\Controllers\Api;

use App\Singer;
use Config;
use Schema;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SingerController extends AbstractController
{
    public function list(Request $request)
    {
        $offset = $request->query->getInt('offset', 0);
        $limit = $request->query->getInt('limit', Config::get('api.limit'));
        $orderBy = $request->query->get('order_by', 'id');
        $direction = $request->query->getBoolean('ascending', true) ? 'ASC' : 'DESC';

        if(!Schema::hasColumn('singers', $orderBy)) {
            abort(JsonResponse::HTTP_BAD_REQUEST, __('messages.request.order_by.invalid_filed'));
        }

        $singers = Singer::query()->orderBy($orderBy, $direction)->offset($offset)->limit($limit);
        $data = [];

        $pagination = [];
        $pagination['count'] = $singers->count();
        $pagination['has_more'] = $pagination['count'] > $offset + $limit;

        foreach ($singers->get() as $key => $singer) {
            $data[$key]['id'] = $singer->id;
            $data[$key]['first_name'] = $singer->first_name;
            $data[$key]['last_name'] = $singer->last_name;
        }

        return $this->result($data, $pagination);
    }

    public function details($id)
    {
        $singer = Singer::query()->findOrFail($id);
        $data = [];

        $data['id'] = $singer->id;
        $data['first_name'] = $singer->first_name;
        $data['last_name'] = $singer->last_name;

        return $this->result($data);
    }
}
