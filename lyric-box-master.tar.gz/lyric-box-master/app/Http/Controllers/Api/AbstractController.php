<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

abstract class AbstractController extends Controller
{
    protected function result($data = true, $pagination = null, $code = JsonResponse::HTTP_OK, $message = null)
    {
        if(isset($data['validation_errors'])) {
            $code = JsonResponse::HTTP_BAD_REQUEST;
        }

        return response()->json(['code' => $code, 'data' => $data, 'pagination' => $pagination, 'message' => $message], $code);
    }

    protected function exception($code = JsonResponse::HTTP_BAD_REQUEST, $message = null)
    {
        return response()->json(['code' => $code, 'message' => $message], $code);
    }

}
