<?php

namespace App\Http\Controllers\Api;

use App\Music;
use Config;
use Schema;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Stichoza\GoogleTranslate\GoogleTranslate;

class MusicScoreController extends AbstractController
{
    public function list(Request $request)
    {
        $offset = $request->query->getInt('offset', 0);
        $limit = $request->query->getInt('limit', Config::get('api.limit'));
        $orderBy = $request->query->get('order_by', 'id');
        $direction = $request->query->getBoolean('ascending', true) ? 'ASC' : 'DESC';

        if(!Schema::hasColumn('musics', $orderBy)) {
            abort(JsonResponse::HTTP_BAD_REQUEST, __('messages.request.order_by.invalid_filed'));
        }

        $musics = Music::query()->orderBy($orderBy, $direction)->offset($offset)->limit($limit);
        $data = [];

        $pagination = [];
        $pagination['count'] = $musics->count();
        $pagination['has_more'] = $pagination['count'] > $offset + $limit;

        foreach ($musics as $key => $music) {
            $data[$key]['id'] = $music->id;
            $data[$key]['title'] = $music->title;
            $data[$key]['poster'] = $music->poster;
            $data[$key]['score'] = round($music->scores()->avg('score'));

            $data[$key]['singer']['id'] = $music->singer->id;
            $data[$key]['singer']['first_name'] = $music->singer->first_name;
            $data[$key]['singer']['last_name'] = $music->singer->last_name;

            $data[$key]['category']['id'] = $music->category->id;
            $data[$key]['category']['name'] = $music->category->name;
        }

        return $this->result($data, $pagination);
    }

    public function details($id)
    {
        return response()->json(GoogleTranslate::trans('hello world', 'fa', 'en'));

        $music = Music::query()->findOrFail($id);
        $data = [];

        $lyric = $music->lyrics()->where('language', '=', app()->getLocale())->first();
        if($lyric === null ) {
            $lyric = $music->lyrics()->where('language', '=', 'en')->first();
            $lyric->text = GoogleTranslate::trans($lyric->text, app()->getLocale(), 'en');
        }

        $data['id'] = $music->id;
        $data['title'] = $music->title;
        $data['poster'] = $music->poster;
        $data['lyric'] = $lyric->text;
        $data['score'] = round($music->scores()->avg('score'));

        $data['singer']['id'] = $music->singer->id;
        $data['singer']['first_name'] = $music->singer->first_name;
        $data['singer']['last_name'] = $music->singer->last_name;

        $data['category']['id'] = $music->category->id;
        $data['category']['name'] = $music->category->name;
        $data['category']['icon'] = $music->category->icon;

        return $this->result($data);
    }
}
