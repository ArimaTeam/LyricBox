<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Singer extends Model
{
    protected $fillable = [
        'first_name', 'last_name'
    ];

    public function musics()
    {
        return $this->hasMany(Music::class);
    }
}
