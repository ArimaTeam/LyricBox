<?php

return [
    'request.query.invalid_filed' => 'امکان درخواست این فیلد وجود ندارد',
    'request.order_by.invalid_filed' => 'امکان استفاده از این فیلد در order_by وجود ندارد',

    'category.details.not_found' => 'دسته بندی مورد نظر وجود ندارد',
    'category.created' => 'دسته ایجاد شد',
    'category.has_books' => 'این دسته قابل حذف نیست',
    'category.deleted' => 'دسته بندی حذف شد',
    'category.pinned.lower_than_three' => 'دسته بندی های انتخاب شده کمتر از سه عدد است.',
    'category.pinned.edited' => 'دسته بندی های نشان شده ویرایش شد',

];
