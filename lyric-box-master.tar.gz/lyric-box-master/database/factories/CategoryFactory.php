<?php

use App\Category;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

/**
 * @var Factory $factory
 */
$factory->define(Category::class, function (Faker $faker) {
    $names = ['Jazz', 'Folk music', 'Hip hop music', 'Rock', 'Pop', 'Blues', 'Classical', 'Punk', 'Funk'];

    return [
        'name' => $faker->randomElement($names),
        'icon' => 'test'
    ];
});
