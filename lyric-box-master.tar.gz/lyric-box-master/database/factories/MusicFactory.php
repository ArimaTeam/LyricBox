<?php


use App\Category;
use App\Music;
use App\Singer;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

/**
 * @var Factory $factory
 */
$factory->define(Music::class, function (Faker $faker) {
    $singers = Singer::all()->pluck('id')->toArray();
    $categories = Category::all()->pluck('id')->toArray();

    return [
        'category_id' => $faker->randomElement($categories),
        'singer_id' => $faker->randomElement($singers),
        'title' => $faker->text(69),
        'poster' => ''
    ];
});
