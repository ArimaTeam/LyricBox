<?php

use App\Lyric;
use App\Music;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

/**
 * @var Factory $factory
 */
$factory->define(Lyric::class, function (Faker $faker) {
    $language = $faker->languageCode;
    $faker = \Faker\Factory::create($language);

    $musics = Music::all()->pluck('id')->toArray();

    return [
        'music_id' => $faker->randomElement($musics),
        'text' => $faker->realText(1000),
        'language' => $language,
    ];
});
