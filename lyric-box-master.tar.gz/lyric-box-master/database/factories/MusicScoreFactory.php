<?php

use App\Music;
use App\MusicScore;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

/**
 * @var Factory $factory
 */
$factory->define(MusicScore::class, function (Faker $faker) {
    $musics = Music::all()->pluck('id')->toArray();

    return [
        'music_id' => $faker->randomElement($musics),
    ];
});
