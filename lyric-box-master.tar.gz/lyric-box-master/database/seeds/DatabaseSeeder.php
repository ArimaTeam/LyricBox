<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Category::class, 10)->create();
        factory(App\User::class, 10)->create();
        factory(App\Singer::class, 10)->create();
        factory(App\Music::class, 10)->create();
        factory(App\Lyric::class, 10)->create();
        factory(App\MusicScore::class, 100)->create();
    }
}
